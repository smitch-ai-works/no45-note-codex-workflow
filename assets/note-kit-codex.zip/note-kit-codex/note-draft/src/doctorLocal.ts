import { existsSync } from 'node:fs';
import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { ROOT } from './paths.js';
const req=createRequire(import.meta.url);const checks:{name:string,ok:boolean}[]=[];
const [major,minor]=process.versions.node.split('.').map(Number);
checks.push({name:'Node.js 22.12以上',ok:major>22 || major===22 && minor>=12});
for(const dep of ['playwright','tsx','gray-matter','markdown-it','zod']){try{req.resolve(dep);checks.push({name:dep,ok:true});}catch{checks.push({name:dep,ok:false});}}
for(const p of ['../AGENTS.md','../profile.json','../.agents/skills/note-article-workflow/SKILL.md','figures/template.html'])checks.push({name:p,ok:existsSync(resolve(ROOT,p))});
console.log(JSON.stringify({local_only:true,browser_launched:false,note_accessed:false,checks},null,2));if(checks.some(x=>!x.ok))process.exitCode=1;
