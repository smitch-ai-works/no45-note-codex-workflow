import { chromium } from 'playwright';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { mkdir } from 'node:fs/promises';
import { dirname } from 'node:path';
const [src,dst]=process.argv.slice(2);
if(!src||!dst)throw Error('図解HTMLと出力PNGを指定してください');
await mkdir(dirname(resolve(dst)),{recursive:true});
const browser=await chromium.launch({headless:true});
try{const page=await browser.newPage({viewport:{width:1080,height:720},deviceScaleFactor:1});await page.goto(pathToFileURL(resolve(src)).href);await page.evaluate(()=>document.fonts.ready);await page.screenshot({path:resolve(dst),clip:{x:0,y:0,width:1080,height:720}});}finally{await browser.close();}
