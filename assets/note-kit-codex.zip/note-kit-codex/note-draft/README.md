# ローカル下書きエンジン / Codex版

通常はキット直下をCodexで開き、日本語で依頼する。利用者がこのコマンドを手入力する必要はない。

- `npm ci --ignore-scripts`：依存関係の準備
- `npm run check-local`：ブラウザもnoteも開かずに環境を点検
- `npm run dry-run -- articles/example-ai-request`：同梱作例の検査
- `npm run login`：許可された環境で、本人がnoteへログイン
- `npm run draft -- articles/記事フォルダ --headed --confirm-draft`：依頼済みの記事を下書き保存（公開しない）

ブラウザ操作ツールの使用方法に制限がある環境では、そのツールのルールを優先する。CLIを迂回手段にしない。

認証状態はstorage/、操作スクショはscreenshots/、ログはlogs/。これらとnode_modules/は配布しない。ブラウザを使わない点検でログイン状態やCookieの内容を表示しない。
下書きの作成開始時に記事フォルダへdraft.lockを作る。成功時はdraft-receipt.jsonへ保存先を記録し、同じ記事での新規下書き作成を止める。失敗時は作成途中のURLを確認し、既存記事に重複して保存しない。公開処理は実装していない。
