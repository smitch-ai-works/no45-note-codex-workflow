import { describe,it,expect } from 'vitest';
import { mkdtempSync,writeFileSync,mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { parseArticle } from '../src/articleParser.js';
import { validateArticle } from '../src/articleValidator.js';
import { createDraft } from '../src/noteDraftWriter.js';
import { resolveRuntimeOptions } from '../src/config.js';
describe('Codex kit input boundaries',()=>{
 it('blocks an image outside the article folder before upload',()=>{const base=mkdtempSync(join(tmpdir(),'note-kit-'));const dir=join(base,'article');mkdirSync(dir);writeFileSync(join(base,'private.png'),'sensitive');writeFileSync(join(dir,'article.md'),'---\ntitle: 記事\n---\n本文\n![不可](../private.png)');expect(validateArticle(parseArticle(dir)).ok).toBe(false);});
 it('keeps a source URL in the text export',()=>{const dir=mkdtempSync(join(tmpdir(),'note-links-'));writeFileSync(join(dir,'article.md'),'---\ntitle: 記事\n---\n[公式](https://example.com/source)');expect(parseArticle(dir).bodyText).toContain('https://example.com/source');});
 it.each(['draft-receipt.json','draft.lock'])('does not open a browser or create another draft when %s exists',async(name)=>{const dir=mkdtempSync(join(tmpdir(),'note-existing-'));writeFileSync(join(dir,'article.md'),'---\ntitle: 記事\n---\n確認用本文');writeFileSync(join(dir,name),'{}');const result=await createDraft(parseArticle(dir),resolveRuntimeOptions({}));expect(result.ok).toBe(false);expect(result.error).toContain('新規作成を繰り返さない');});
});
